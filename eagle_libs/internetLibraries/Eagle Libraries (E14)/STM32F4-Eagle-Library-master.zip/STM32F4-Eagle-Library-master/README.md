stm32f4
=======

Eagle files and references for easy addition of STM32F407 and peripherals.
